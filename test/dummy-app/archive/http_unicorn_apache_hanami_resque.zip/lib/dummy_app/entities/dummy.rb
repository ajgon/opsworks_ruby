class Dummy
  include Hanami::Entity
  attributes :field
end
