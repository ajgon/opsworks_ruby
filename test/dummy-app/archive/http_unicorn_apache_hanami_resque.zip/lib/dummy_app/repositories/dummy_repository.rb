class DummyRepository
  include Hanami::Repository
end
