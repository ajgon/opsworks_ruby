module Web::Views::Home
  class Index
    include Web::View
  end
end
