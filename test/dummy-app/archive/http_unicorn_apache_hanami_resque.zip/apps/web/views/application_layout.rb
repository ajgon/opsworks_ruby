module Web
  module Views
    class ApplicationLayout
      include Web::Layout
    end
  end
end
