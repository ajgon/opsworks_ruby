require 'spec_helper'

describe Dummy do
  # place your tests here
end
