require 'spec_helper'

describe DummyRepository do
  # place your tests here
end
