# Helper methods defined here can be accessed in any controller or view in the application

module DummyApp
  class App
    module HomeHelper
      # def simple_helper_method
      # ...
      # end
    end

    helpers HomeHelper
  end
end
