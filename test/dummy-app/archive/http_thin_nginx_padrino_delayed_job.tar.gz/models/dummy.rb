class Dummy < ActiveRecord::Base

end
